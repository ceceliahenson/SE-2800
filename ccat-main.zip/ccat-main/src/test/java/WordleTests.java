import javafx.application.Application;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import org.junit.jupiter.api.*;
import javafx.scene.input.KeyEvent;

import java.io.FileNotFoundException;

public class WordleTests {

    Controller controller;
    Row row;

    @BeforeAll
    static void launch() {
        Application.launch(Main.class);
    }

    @BeforeEach
    void setup() throws FileNotFoundException {
        controller = new Controller();
        controller.wordleHolder = new VBox();
        controller.guessedCol1 = new VBox();
        controller.guessedCol2 = new VBox();
        controller.guessedCol3 = new VBox();
        controller.numGuess = new Label();
        controller.mainContainer = new VBox();
        controller.alert = new VBox();
        controller.initialize();
    }

    @Test
    @DisplayName("Valid tables.Word Tests")
    void validWord(){
        Assertions.assertTrue(controller.validWord("party"));
        Assertions.assertFalse(controller.validWord("asdfg"));
        Assertions.assertFalse(controller.validWord("asd"));
        Assertions.assertFalse(controller.validWord("multiple"));
    }

    @Test
    void numberOfGuesses(){
        Assertions.assertNotEquals("hello", controller.secretWord);
        Assertions.assertNotEquals("", controller.secretWord);
        Assertions.assertNotEquals("longest", controller.secretWord);
        Assertions.assertNotEquals(12345, controller.secretWord);
        Assertions.assertNotEquals(false, controller.secretWord);
    }

    @Test
    @DisplayName("Generate Grid")
    void generateGrid() {
        // controller.generateGrid() runs as part of the initialize in the @BeforeEach
        Assertions.assertNotNull(controller.rows[0]);
        Assertions.assertNotNull(controller.rows[Controller.DEFAULT_WORD_LENGTH - 1]);
        Assertions.assertTrue(controller.wordleHolder.getChildren().size() != 0);
    }

    @Test
    @DisplayName("Keypress")
    void keyPressHandler() {
        Assertions.assertEquals(controller.currentWord, "");
        controller.keyPressHandler(new KeyEvent(KeyEvent.KEY_PRESSED, "", KeyCode.A.toString(),
                KeyCode.A, false, false, false, false));
        controller.keyPressHandler(new KeyEvent(KeyEvent.KEY_PRESSED, "", KeyCode.B.toString(),
                KeyCode.B, false, false, false, false));
        Assertions.assertEquals(controller.currentWord, "ab");
        controller.keyPressHandler(new KeyEvent(KeyEvent.KEY_PRESSED, "",
                KeyCode.DIGIT1.toString(), KeyCode.DIGIT1, false, false, false, false));
        Assertions.assertEquals(controller.currentWord, "ab");
        controller.keyPressHandler(new KeyEvent(KeyEvent.KEY_PRESSED, "",
                KeyCode.BACK_SPACE.toString(), KeyCode.BACK_SPACE, false, false, false, false));
        Assertions.assertEquals(controller.currentWord, "a");
        controller.keyPressHandler(new KeyEvent(KeyEvent.KEY_PRESSED, "", KeyCode.U.toString(),
                KeyCode.U, false, false, false, false));
        controller.keyPressHandler(new KeyEvent(KeyEvent.KEY_PRESSED, "", KeyCode.D.toString(),
                KeyCode.D, false, false, false, false));
        controller.keyPressHandler(new KeyEvent(KeyEvent.KEY_PRESSED, "", KeyCode.I.toString(),
                KeyCode.I, false, false, false, false));
        controller.keyPressHandler(new KeyEvent(KeyEvent.KEY_PRESSED, "", KeyCode.O.toString(),
                KeyCode.O, false, false, false, false));
        Assertions.assertEquals(controller.currentWord, "audio");
        Assertions.assertEquals(controller.guessNumber, 0);
        controller.keyPressHandler(new KeyEvent(KeyEvent.KEY_PRESSED, "",
                KeyCode.ENTER.toString(), KeyCode.ENTER, false, false, false, false));
        Assertions.assertEquals(controller.guessNumber, 1);
        Assertions.assertEquals(controller.currentWord, "");
        controller.keyPressHandler(new KeyEvent(KeyEvent.KEY_PRESSED, "",
                KeyCode.BACK_SPACE.toString(), KeyCode.BACK_SPACE, false, false, false, false));
        Assertions.assertEquals(controller.currentWord, "");
    }

    @Test
    @DisplayName("Generate Guessed Letters")
    void generateGuessedLetters() {
        // generateGuessedLetters() runs as part of the initialize function in the @BeforeEach
        for(String letter : Controller.ALPHABET) {
            Assertions.assertNotNull(controller.guessedLetters.get(letter));
        }
    }

    @Test
    @DisplayName("LetterStatus")
    void letterStatus() {
        Assertions.assertEquals(LetterStatus.CORRECT.getStyleClass(), "correct");
        Assertions.assertEquals(LetterStatus.WRONG_SPOT.getStyleClass(), "wrong-spot");
        Assertions.assertEquals(LetterStatus.INCORRECT.getStyleClass(), "incorrect");
    }

    @Test
    @DisplayName("LetterBox")
    void letterBox() {
        row = new Row(5, new HBox());
        Assertions.assertNotNull(row.getLetter(0));
        Assertions.assertNotNull(row.getLetter(4));
        Assertions.assertNull(row.getLetter(5));
    }
}
