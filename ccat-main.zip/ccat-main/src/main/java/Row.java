import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;

/**
 * @author Coltrane
 *
 * A row containing any number of LetterBoxes. Each row corresponds to a word guess.
 */
public class Row {
    private final static int SPACING = 15;
    private final LetterBox[] letters;

    public Row(int size, HBox pane) {
        LetterBox newLetter;
        Label newLabel;
        pane.setPadding(new Insets(SPACING, 0, 0, 0));
        pane.setSpacing(SPACING);
        letters = new LetterBox[size];
        for(int i = 0; i < size; i++) {
            newLabel = new Label();
            newLetter = new LetterBox(newLabel);
            letters[i] = newLetter;
            pane.getChildren().add(newLabel);
        }
    }

    public LetterBox getLetter(int index) {
        return index < letters.length ? letters[index] : null;
    }
}
