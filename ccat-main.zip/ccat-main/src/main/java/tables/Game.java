package tables;

import jakarta.persistence.*;

@Entity
@Table(name = "game")
public class Game {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "game_id")
    private int gameId;

    @Column(name = "guess_count", nullable = false)
    private int guessCount;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    public Game(User user, int guessCount) {
        this.user = user;
        this.guessCount = guessCount;
    }

    public Game() {

    }
}
