package tables;

import jakarta.persistence.*;

@Entity
@Table(name = "letter")
public class Letter {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "letter_id")
    private int letterId;

    @Column(name = "letter", nullable = false)
    private char letter;

    @Column(name = "guess_count", nullable = false, columnDefinition = "INT DEFAULT 1")
    private int guessCount;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    public Letter(char letter, User user) {
        this.letter = letter;
        this.user = user;
        // This line should be unnecessary, but it doesn't work correctly without it
        this.guessCount = 1;
    }

    public Letter() {

    }

    public void increment() {
        guessCount += 1;
    }

    public int getGuessCount(){
        return guessCount;
    }

    public char getLetter(){
        return letter;
    }
}