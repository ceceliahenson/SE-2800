package tables;

import jakarta.persistence.*;

@Entity
@Table(name = "user")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private int userId;

    @Column(name = "username", nullable = false)
    private String username;

    public User(String username) {
        this.username = username;
    }

    public int getUserId() {
        return userId;
    }

    public User() {

    }
}