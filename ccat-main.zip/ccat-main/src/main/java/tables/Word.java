package tables;

import jakarta.persistence.*;

@Entity
@Table(name = "word")
public class Word {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "word_id")
    private int wordId;

    @Column(name = "word", nullable = false)
    private String word;

    @Column(name = "guess_count", nullable = false, columnDefinition = "INT DEFAULT 1")
    private int guessCount;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    public Word(String word, User user) {
        this.word = word;
        this.user = user;
        // This line should be unnecessary, but it doesn't work correctly without it
        this.guessCount = 1;
    }

    public Word() {

    }

    public void increment() {
        guessCount += 1;
    }

    public String getWord() {
        return word;
    }

    public int getGuessCount() {
        return guessCount;
    }
}