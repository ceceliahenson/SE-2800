/**
 * @author Coltrane
 *
 * Enum that stores whether a letterbox corresponds to a letter that is in the word in the right
 * spot(CORRECT), in the word in the wrong spot (WRONG_SPOT), or not in the word (INCORRECT)
 */
public enum LetterStatus {
    CORRECT("correct"),
    WRONG_SPOT("wrong-spot"),
    INCORRECT("incorrect");

    // Style class for CSS styling
    private final String styleClass;

    LetterStatus(String styleClass) {
        this.styleClass = styleClass;
    }

    public String getStyleClass() {
        return styleClass;
    }
}
