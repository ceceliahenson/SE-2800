import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;

import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.util.*;
import java.util.stream.Collectors;

import javafx.util.Duration;
import tables.Letter;
import tables.Word;

public class Controller {
    public final static int DEFAULT_WORD_LENGTH = 5;
    public final static int DEFAULT_GUESSES = 6;
    public final static String[] ALPHABET = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j",
            "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};
    public final static String adminPassword = "password";
    @FXML
    Button score;
    @FXML
    private Label timeLabel;
    @FXML
    public Label numGuess;
    @FXML
    public VBox wordleHolder;
    @FXML
    public VBox mainContainer;
    @FXML
    public VBox guessedCol1;
    @FXML
    public VBox guessedCol2;
    @FXML
    public VBox guessedCol3;
    @FXML
    public VBox alert;
    @FXML
    public Label alertLabel;
    @FXML
    public HBox mainGame;
    @FXML
    public VBox statsWindow;
    @FXML
    public VBox adminAlert;
    @FXML
    public PasswordField adminPasswordField;
    @FXML
    public GridPane rootPane;
    @FXML
    public Label logoLabel;
    @FXML
    public Menu adminMenu;
    @FXML
    public Label secretWordLabel;
    @FXML
    public VBox letterChartHolder;
    @FXML
    public Label avgGuessesLabel;
    @FXML
    public TextArea wordStatsArea;
    @FXML
    public Label orderButton;
    @FXML
    public Label statsTitle;
    @FXML
    public HBox recommendedWordsWindow;
    @FXML
    public VBox easyWords;
    @FXML
    public VBox medWords;
    @FXML
    public VBox hardWords;
    @FXML
    public Label aiGuess;

    public ArrayList<String> dictionary = new ArrayList<>();
    public int guessNumber;
    public String secretWord;
    public int wordLength = DEFAULT_WORD_LENGTH;
    public int totalGuesses = DEFAULT_GUESSES;
    public Row[] rows;
    public String currentWord;
    public String prevGuess;
    public HashMap<String, LetterBox> guessedLetters;

    public DatabaseConnector databaseConnector = new DatabaseConnector();

    public boolean admin = false;
    public List<Word> focusWordList;
    public List<Letter> focusLetterList;
    public long[] focusGuessNumList;
    public boolean descendingOrder = true;
    public double focusAverageGuesses;
    private Timeline timeline;
    private Duration timeElapsed = Duration.ZERO;
    private List<Duration> recordedTimes = new ArrayList<Duration>();

    private ArrayList<Character> wrongLetters = new ArrayList<>();
    private HashMap<Character, Integer> wrongSpotLetters = new HashMap<Character, Integer>();
    private HashMap<Character, Integer> correctLetters = new HashMap<Character, Integer>();
    private ArrayList<String> remainingWords = new ArrayList<>();

    /**
     * initializes program with the import of the wordle txt
     */
    @FXML
    public void initialize() throws FileNotFoundException {
        mainContainer.requestFocus();
        FileReader.importFiles(dictionary);
        remainingWords.addAll(dictionary);
        resetStopwatch();
        newGame();
    }

    /**
     * Resets the UI for a new game.
     */
    @FXML
    private void newGame() throws FileNotFoundException {
        resetStopwatch();
        startStopwatch();
        remainingWords = new ArrayList<>();
        remainingWords.addAll(dictionary);
        // Clear UI
        alert.setVisible(false);
        wordleHolder.getChildren().clear();
        guessedCol1.getChildren().clear();
        guessedCol2.getChildren().clear();
        guessedCol3.getChildren().clear();
        // Reset variables
        rows = new Row[totalGuesses];
        currentWord = "";
        guessNumber = 0;
        // Rebuild UI
        numGuess.setText("GUESSES: 0");
        generateGrid();
        randomWord();
        generateGuessedLetters();

    }

    public void displayStats(){
        DatabaseConnector.StatHolder stats = databaseConnector.statsLocal(totalGuesses);
        clearWindows();
        statsWindow.setVisible(true);
        focusGuessNumList = stats.getGuessNums();
        focusLetterList = stats.getLetters();
        focusWordList = stats.getWords();
        focusAverageGuesses = stats.getAverage();
        descendingOrder = true;
        orderButton.setText("▼");
        statsTitle.setText("User Stats");
        generateGraphs();
    }

    public void showLetterHint(){
        //https://www.geeksforgeeks.org/javafx-textinputdialog/
        //Get user input for desired letter pos
        //Display correct letter for that position

        TextInputDialog dialog = new TextInputDialog("Letter Position");
        dialog.setTitle("Letter Hint");
        dialog.setHeaderText("Choose letter position (0-4)");
        dialog.showAndWait();

        int letterPos = 0;
        boolean valid = false;

        try {
            letterPos = Integer.parseInt(dialog.getEditor().getText());
            if (letterPos > 4 || letterPos < 0) {
                throw new NumberFormatException();
            } else {
                valid = true;
            }
        } catch (NumberFormatException e) {
            System.out.println("Input must be an integer from 0-4");
        }

        String hint = "";
        for (int i = 0; i < 5; i++) {
            if (i == letterPos) {
                hint += secretWord.charAt(i);
            } else {
                hint += "_";
            }
            hint += " ";
        }

        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle("Letter Hint");
        a.setHeaderText("Letter Hint");
        if (valid) {
            a.setContentText(hint);
        } else {
            a.setContentText("Input invalid, please try again.");
        }
        a.show();
    }

    public void showWordHint(){
        //Returns 5 possible words 30 points better than the current word, with an 80 point max
        int currentScore = calcWordScore(prevGuess);
        int tgtScore = Math.min(currentScore + 30, 80);
        ArrayList<String> possibleWords = new ArrayList<>();

        if(currentScore < 80) {
            for (String s : dictionary) {
                if (calcWordScore(s) == tgtScore) {
                    possibleWords.add(s);
                }
                if (possibleWords.size() == 5) {
                    break;
                }
            }
        }

        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle("Word Hint");
        a.setHeaderText("Possible Words");
        if(currentScore < 80) {
            for (String s : possibleWords) {
                a.setContentText(a.getContentText() + "\n" + s);
            }
        } else {
            a.setContentText("Too close to answer, can not give a hint.");
        }
        a.show();
    }

    private int calcWordScore(String word){
        //0 is the minimum score
        //100 is the maximum score
        //0 points for incorrect letter
        //10 points for a yellow (partially correct) letter
        //20 points for a green (correct) letter
        int score = 0;
        if(word != null) {
            for (int i = 0; i < secretWord.length(); i++) {
                if (word.charAt(i) == secretWord.charAt(i)) {
                    score += 20;
                } else if (secretWord.contains(String.valueOf(word.charAt(i)))) {
                    score += 10;
                }
            }
        }
        return score;
    }

    private void generateGraphs() {
        HashSet<String> guessedLetters = new HashSet<>();
        letterChartHolder.getChildren().clear();

        BarChart<Number, String> guessNumChart = new BarChart<>(new NumberAxis(), new CategoryAxis());
        guessNumChart.setLegendVisible(false);
        guessNumChart.setMaxHeight(190);
        guessNumChart.setMaxWidth(351);
        guessNumChart.setBarGap(0);
        guessNumChart.setCategoryGap(5);
        guessNumChart.setTitle("Number of Guesses Needed");
        XYChart.Series<Number, String> guessNumData = new XYChart.Series<>();

        for(int i = 0; i < totalGuesses; ++i) {
            guessNumData.getData().add(new XYChart.Data<>(focusGuessNumList[i], String.valueOf(i + 1)));
        }

        guessNumChart.getData().add(guessNumData);
        letterChartHolder.getChildren().add(guessNumChart);

        BarChart<String, Number> letterChart = new BarChart<>(new CategoryAxis(), new NumberAxis());
        letterChart.setLegendVisible(false);
        letterChart.setMaxHeight(245);
        letterChart.setMaxWidth(375);
        letterChart.setBarGap(0);
        letterChart.setCategoryGap(3);
        letterChart.setTitle("Most Common Letters Guessed");
        XYChart.Series<String, Number> letterData = new XYChart.Series<>();

        for(Letter letter : focusLetterList){
            letterData.getData().add(new XYChart.Data<>(String.valueOf(letter.getLetter()),
                    letter.getGuessCount()));
            guessedLetters.add(String.valueOf(letter.getLetter()));
        }
        for(String letter : ALPHABET) {
            if(!guessedLetters.contains(letter)) {
                letterData.getData().add(new XYChart.Data<>(letter, 0));
            }
        }
        letterChart.getData().add(letterData);
        letterChartHolder.getChildren().add(letterChart);

        DecimalFormat rounder = new DecimalFormat("#.##");
        avgGuessesLabel.setText("Avg Guesses: " + rounder.format(focusAverageGuesses));

        StringBuilder wordsString = new StringBuilder();
        for(Word word : focusWordList){
            wordsString.append(word.getWord());
            wordsString.append(": ");
            wordsString.append(word.getGuessCount());
            wordsString.append("\n");
        }
        wordStatsArea.setText(wordsString.toString().stripTrailing());
    }

    /**
     * Author: Cece
     * generates random word from list
     */
    private void randomWord(){
        int randomIndex = (int) (Math.random() * dictionary.size());
        System.out.println( "Random Word: " +  dictionary.get( randomIndex ) );
        secretWord = dictionary.get( randomIndex );
        secretWordLabel.setText("Secret Word: " + secretWord);
    }

    /**
     * On an enter press, this method checks if the
     * word is valid and if it is accordingly calls methods to
     * correctly update the GUI. If the word isn't valid it will
     * shake the letters.
     */
    private void enter(){
        if(!validWord(currentWord)){
            for(int i = 0; i < wordLength; i++) {
                rows[guessNumber].getLetter(i).shake();
            }
        }else{
            prevGuess = currentWord;
            Thread thread = new Thread(() -> databaseConnector.addWord(currentWord));
            thread.start();
            colorChars(currentWord);
            updateRemainingWords();
            numGuesses(currentWord);
        }
    }

    /**
     * Author: Trevor
     * Colors letters based on the word guessed
     */
    private void colorChars(String word){
        String character;

        for(int i = 0; i < word.length(); i++){
            character = String.valueOf(word.charAt(i));
            if(word.charAt(i) == secretWord.charAt(i)){ //if letter is in right position
                rows[guessNumber].getLetter(i).setStatus(LetterStatus.CORRECT);
                guessedLetters.get(character).setStatus(LetterStatus.CORRECT);
                correctLetters.put(word.charAt(i), i);
            } else if(secretWord.contains(String.valueOf(word.charAt(i)))){ //if letter is in word, but wrong place
                wrongSpotLetters.put(word.charAt(i), i);
                rows[guessNumber].getLetter(i).setStatus(LetterStatus.WRONG_SPOT);
                guessedLetters.get(character).setStatus(LetterStatus.WRONG_SPOT);
            } else{ //letter not in word
                rows[guessNumber].getLetter(i).setStatus(LetterStatus.INCORRECT);
                guessedLetters.get(character).setStatus(LetterStatus.INCORRECT);
                wrongLetters.add(word.charAt(i));
            }
        }
    }

    /**
     * @author Aydin Ruppe
     * @param word word to be checked
     * @return true if word is valid, false otherwise
     */
    public boolean validWord(String word){
        return word.length() == wordLength && dictionary.contains(word);
    }

    /**
     * author: cece
     *
     * this method takes in the guesses from the textbox
     * from the user and adds it to the number of guesses total
     *
     * displays a pop up if the word is guessed before or on the 6th
     * guess and if it is not correctly guessed by the 6th guess
     * @param word
     */
    public void numGuesses(String word){
        if(validWord(word)){
            guessNumber += 1;
            currentWord = "";
            numGuess.setText("GUESSES: " + guessNumber);
            if(guessNumber <= totalGuesses && word.equals(secretWord)){
                Thread thread = new Thread(() -> databaseConnector.addGame(guessNumber));
                thread.start();
                stopStopwatch();

                alert.setVisible(true);
                alertLabel.setText("You guessed the word!");
                //startStopwatch();
            }else if(!word.equals(secretWord) && guessNumber == totalGuesses){
                stopStopwatch();
                alert.setVisible(true);
                alertLabel.setText("sad life you did not guess word");
                //stopStopwatch();
            }
        }
    }

    /**
     * @author Coltrane
     *
     * Creates an empty Wordle grid
     */
    private void generateGrid() {
        HBox newHBox;
        Row newRow;
        for(int i = 0; i < totalGuesses; i++) {
            newHBox = new HBox();
            newRow = new Row(wordLength, newHBox);
            rows[i] = newRow;
            wordleHolder.getChildren().add(newHBox);
        }
    }

    /**
     * @author Coltrane
     *
     * Handles a keypress by adding a letter key to the current word if there's space, removing a
     * letter from the current word for backspace, or triggering the "enter" functionality on enter
     * if the word is complete
     * @param keyEvent The keypress event
     */
    @FXML
    public void keyPressHandler(KeyEvent keyEvent) {
        KeyCode keyCode = keyEvent.getCode();
        if (keyCode == KeyCode.ENTER && currentWord.length() >= wordLength) {
            enter();
        } else if (keyCode == KeyCode.BACK_SPACE && currentWord.length() > 0) {
            currentWord = currentWord.substring(0, currentWord.length() - 1);
            rows[guessNumber].getLetter(currentWord.length()).setText("");
        } else if (keyCode.isLetterKey() && currentWord.length() < wordLength) {
            rows[guessNumber].getLetter(currentWord.length()).setText(keyCode.toString());
            currentWord += keyCode.toString().toLowerCase();
        }
    }

    /**
     * @author Coltrane
     *
     * Creates a new hashmap that maps each letter of the alphabet to a LetterBlock. This keeps
     * track of the "Guessed Letters" grid.
     */
    private void generateGuessedLetters() {
        guessedLetters = new HashMap<>();
        LetterBox letterBox;
        Label letterLabel;
        for(int i = 0; i < 9; i++) {
            letterLabel = new Label(ALPHABET[i].toUpperCase());
            letterBox = new LetterBox(letterLabel, true);
            guessedLetters.put(ALPHABET[i], letterBox);
            guessedCol1.getChildren().add(letterLabel);

            letterLabel = new Label(ALPHABET[i + 9].toUpperCase());
            letterBox = new LetterBox(letterLabel, true);
            guessedLetters.put(ALPHABET[i + 9], letterBox);
            guessedCol2.getChildren().add(letterLabel);

            if (i < 8) {
                letterLabel = new Label(ALPHABET[i + 18].toUpperCase());
                letterBox = new LetterBox(letterLabel, true);
                guessedLetters.put(ALPHABET[i + 18], letterBox);
                guessedCol3.getChildren().add(letterLabel);
            }
        }
    }

    /**
     * Author: Cece
     * This method has the admin login and change the .txt file
     * that is being used in the Wordle game and starts a new game after
     * new file is selected.
     */
    @FXML
    private void showAdminLogin(){
        if (!admin) {
            adminAlert.setVisible(true);
        }
    }

    /**
     * Hides every window so that we can change to a new window
     */
    public void clearWindows() {
        mainGame.setVisible(false);
        statsWindow.setVisible(false);
    }

    @FXML
    public void showGame() throws FileNotFoundException {
        clearWindows();
        mainGame.setVisible(true);
        newGame();
    }

    @FXML
    public void adminSignIn() {
        if (adminPasswordField.getText().equals(adminPassword)) {
            rootPane.getStyleClass().add("admin-mode");
            adminAlert.setVisible(false);
            logoLabel.setText("ADMIN");
            adminMenu.setVisible(true);
            secretWordLabel.setVisible(true);
            admin = true;
        }
        adminPasswordField.setText("");
    }

    @FXML
    public void adminCancel() {
        adminPasswordField.setText("");
        adminAlert.setVisible(false);
    }

    @FXML
    public void turnOffAdmin() {
        rootPane.getStyleClass().remove("admin-mode");
        logoLabel.setText("WORDLE");
        adminMenu.setVisible(false);
        secretWordLabel.setVisible(false);
        admin = false;
    }

    @FXML
    public void changeDictionary() {
        try {
            dictionary.clear();
            FileReader.adminImport(dictionary);
            newGame();
        } catch (FileNotFoundException ex) {
            throw new RuntimeException(ex);
        }
    }

    @FXML
    public void backToGame() {
        clearWindows();
        mainGame.setVisible(true);
    }

    @FXML
    public void swapOrder() {
        Collections.reverse(focusWordList);
        generateGraphs();
        orderButton.setText(descendingOrder ? "▲" : "▼");
        descendingOrder = !descendingOrder;
    }

    @FXML
    public void globalStats() {
        DatabaseConnector.StatHolder stats = databaseConnector.statsGlobal(totalGuesses);
        clearWindows();
        statsWindow.setVisible(true);
        focusGuessNumList = stats.getGuessNums();
        focusLetterList = stats.getLetters();
        focusWordList = stats.getWords();
        focusAverageGuesses = stats.getAverage();
        descendingOrder = true;
        orderButton.setText("▼");
        statsTitle.setText("Global Stats");
        generateGraphs();
    }

    public double getRecommendScore(String guess, String base) {
        double score = 0;
        if (guess.length() == wordLength) {
            for (int i = 0; i < wordLength; ++i) {
                if (guess.charAt(i) == base.charAt(i)) {
                    score += 1. / wordLength;
                } else if (base.indexOf(guess.charAt(i)) != -1) {
                    score += 0.5 / wordLength;
                }
            }
        }
        return score;
    }

    public void recommendedWords() {
        List<Word> guessedWords = databaseConnector.getWordListGlobal();
        List<String> checkedWords = new ArrayList<>(dictionary);
        int totalWords = guessedWords.stream().mapToInt(Word::getGuessCount).sum();
        Map<String, Double> scores;

        // Get 100 random words from the dictionary
        Collections.shuffle(checkedWords);
        checkedWords = checkedWords.subList(0, Math.min(checkedWords.size(), 100));

        // Map each word to its score based on the weighted average of the scores from guessed
        // words
        scores = checkedWords.parallelStream()
                .collect(Collectors.toConcurrentMap(word -> word, word -> guessedWords
                        .parallelStream()
                        .mapToDouble(guess -> getRecommendScore(guess.getWord(), word) *
                        ((double) guess.getGuessCount() / totalWords))
                        .sum()));

        // Sort the words based on their scores
        checkedWords.sort(Comparator.comparingDouble(scores::get));

        easyWords.getChildren().clear();
        medWords.getChildren().clear();
        hardWords.getChildren().clear();

        for (int i = Math.max(checkedWords.size() - 10, 0); i < checkedWords.size(); ++i) {
            easyWords.getChildren().add(new Label(checkedWords.get(i)));
        }

        for (int i = Math.max(checkedWords.size() / 2 - 5, 0);
             i < checkedWords.size() / 2 + 5 && i < checkedWords.size(); ++i) {
            medWords.getChildren().add(new Label(checkedWords.get(i)));
        }

        for (int i = 0; i < 10 && i < checkedWords.size(); ++i) {
            hardWords.getChildren().add(new Label(checkedWords.get(i)));
        }

        clearWindows();
        recommendedWordsWindow.setVisible(true);
    }


    /**
     * Author: Cece
     * starts the stopwatch
     */
    public void startStopwatch(){
        if (timeline == null) {
            timeline = new Timeline(new KeyFrame(Duration.millis(10), e -> updateStopwatch()));
            timeline.setCycleCount(Animation.INDEFINITE);
        }
        timeline.play();
    }

    /**
     * Author: Cece
     * stops the stopwatch
     */
    public void stopStopwatch() {
        if (timeline != null) {
            timeline.pause();
            recordedTimes.add(timeElapsed);
            timeElapsed = Duration.ZERO;
        }
    }

    /**
     * Author: Cece
     * rests the stopwatch
     */
    public void resetStopwatch() {
        timeElapsed = Duration.ZERO;
        updateStopwatch();
        if (timeline != null) {
            timeline.stop();
            timeline = null;
        }
    }

    /**
     * Author: Cece
     * this method updates the stopwatch and converts the time
     */
    private void updateStopwatch() {
        timeElapsed = timeElapsed.add(Duration.millis(10));
        int minutes = (int) timeElapsed.toMinutes();
        int seconds = (int) (timeElapsed.toSeconds() % 60);
        int millis = (int) (timeElapsed.toMillis() % 1000);
        String time = String.format("%02d:%02d:%02d", minutes, seconds, millis / 10);
        timeLabel.setText(time);
    }

    /**
     * Author: Cece
     * this method displays the recored time scores of the wordle
     * @param actionEvent
     */
    @FXML
    public void scoreBoard(ActionEvent actionEvent) {
        if (recordedTimes.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "No times recorded yet.");
            alert.showAndWait();
            return;
        }

        Dialog<List<Duration>> dialog = new Dialog<>();
        dialog.setTitle("Scoreboard");
        dialog.setHeaderText("Recorded Times:");

        ButtonType closeButton = new ButtonType("Close", ButtonBar.ButtonData.CANCEL_CLOSE);
        dialog.getDialogPane().getButtonTypes().addAll(closeButton);

        ListView<String> listView = new ListView<>();
        listView.setPrefWidth(300);
        List<Duration> sortedTimes = new ArrayList<>(recordedTimes);
        Collections.sort(sortedTimes);

        for (int i = 0; i < sortedTimes.size(); i++) {
            Duration time = sortedTimes.get(i);
            int minutes = (int) time.toMinutes();
            int seconds = (int) (time.toSeconds() % 60);
            int millis = (int) (time.toMillis() % 1000);
            String timeString = String.format("%02d:%02d:%02d", minutes, seconds, millis / 10);
            listView.getItems().add(String.format("%d. %s", i + 1, timeString));
        }
        dialog.getDialogPane().setContent(listView);
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == closeButton) {
                return null;
            }
            return null;
        });
        dialog.showAndWait();
    }

    /**
     * @author Aydin Ruppe
     * updates the GUI label for ai Guess to have a random guess from the remaining word list.
     */
    @FXML
    public void generateAIGuess(){
        Random gen = new Random();
        int index = gen.nextInt(remainingWords.size());
        aiGuess.setText(remainingWords.get(index));
    }

    /**
     * @author Aydin Ruppe
     *
     * Method updates the remaining word list to only have words that could be the possible answer.
     * Uses letter lists of wrong letters, wrong spot letters, and correct letters with their indices
     * to figure out if a word should stay in the remaining word list or not.
     */
    public void updateRemainingWords(){
        ArrayList<String> removals = new ArrayList<>();
        for(Character character : wrongLetters){
            for(String word : remainingWords) {
                if (word.contains(character.toString())){
                    removals.add(word);
                }
            }
        }
        wrongLetters.clear();
        for(Character character : wrongSpotLetters.keySet()) {
            for (String word : remainingWords) {
                if (!word.contains(character.toString()) || word.charAt(wrongSpotLetters.get(character)) == character){
                    removals.add(word);
                }
            }
        }
        wrongSpotLetters.clear();
        for(Character character: correctLetters.keySet()) {
            for (String word : remainingWords) {
                if (!word.contains(character.toString()) || word.charAt(correctLetters.get(character)) != character) {
                    removals.add(word);
                }
            }
        }
        correctLetters.clear();
        remainingWords.removeAll(removals);
    }
}
