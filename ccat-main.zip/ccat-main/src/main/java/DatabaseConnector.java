import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import tables.Game;
import tables.Letter;
import tables.User;
import tables.Word;

import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Allows the backend to easily connect ot the database.
 */
public class DatabaseConnector {

    private static SessionFactory sessionFactory;
    private User currentUser;
    private User globalUser;
    private ReentrantLock lock;

    /**
     * Creates the database connector and allows it to keep track of the current user.
     */
    public DatabaseConnector() {
        lock = new ReentrantLock();
        // Create a new sessionFactory if one doesn't exist
        // The SessionFactory is an object that creates Sessions, which can be used to connect to
        // the databse
        if (sessionFactory == null) {
            StandardServiceRegistry registry = new StandardServiceRegistryBuilder().configure()
                    .build();
            try {
                // Make sure the SessionFactory can see the classes representing our tables
                MetadataSources metadataSources = new MetadataSources(registry);
                metadataSources.addAnnotatedClass(User.class);
                metadataSources.addAnnotatedClass(Letter.class);
                metadataSources.addAnnotatedClass(Word.class);
                metadataSources.addAnnotatedClass(Game.class);
                sessionFactory = metadataSources.buildMetadata().buildSessionFactory();
            } catch (Exception e) {
                e.printStackTrace();
                StandardServiceRegistryBuilder.destroy(registry);
            }
        }

        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            // Find the global user
            globalUser = addUser("global", session);
            // Find the current user
            currentUser = addUser(session);
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    // If the given user does not exist in the table, add it to the table. Then, return the user
    private User addUser(String username, Session session) {
        // Look for a user with the given username
        User user = session
                .createQuery("FROM User u WHERE u.username = :username", User.class)
                .setParameter("username", username)
                .uniqueResult();
        // If that user doesn't exist, add it
        if (user == null) {
            user = new User(username);
            session.persist(user);
        }
        return user;
    }

    // Get a unique username associated with this computer
    private String getUsername() {
        // Get the MAC address of the current computer
        byte[] macAddress = null;
        try {
            Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
            while (networkInterfaces.hasMoreElements()) {
                NetworkInterface networkInterface = networkInterfaces.nextElement();
                if (!networkInterface.isLoopback() && !networkInterface.isVirtual() &&
                        networkInterface.getHardwareAddress() != null) {
                    macAddress = networkInterface.getHardwareAddress();
                    break;
                }
            }
        } catch (SocketException e) {
            e.printStackTrace();
        }

        // If the MAC address cannot be found, just use the name "unknown"
        String uniqueIdString = "unknown";
        // Otherwise, convert the MAC address into a string to be used as a username
        if (macAddress != null) {
            StringBuilder sb = new StringBuilder();
            for (byte b : macAddress) {
                sb.append(String.format("%02X", b));
            }
            uniqueIdString = sb.toString();
        }
        return uniqueIdString;
    }

    // If the current user isn't in the database, add it. Then, return that user
    private User addUser(Session session) {
        return addUser(getUsername(), session);
    }

    // Add a word to the database by adding a new row if this is the user's first time guessing
    // that word, or incrementing the "guess_count" of the letter otherwise
    private void addWord(String word, User user, Session session) {
        // Keep track of which letters we've seen already in words with duplicate letters
        HashMap<Character, Letter> letterMap = new HashMap<>();
        Letter newLetter;
        // Find the word row for the given letter and the given user
        Word newWord = session
                .createQuery("FROM Word w WHERE w.word = :word AND w.user = :userId", Word.class)
                .setParameter("word", word)
                .setParameter("userId", user)
                .uniqueResult();
        // If there is no word row, add one
        if (newWord == null) {
            newWord = new Word(word, user);
        } else {
            // Otherwise, increment the guess_count
            newWord.increment();
        }

        // Update the word to the database
        session.persist(newWord);

        // Also add every letter in the word
        for (char ch : word.toCharArray()) {
            // If the letter isn't appearing in the word a second time
            if (!letterMap.containsKey(ch)) {
                // Look for the letter in the database
                newLetter = session.createQuery(
                        "FROM Letter l WHERE l.letter = :letter AND l.user = :userId",
                                Letter.class)
                        .setParameter("letter", ch)
                        .setParameter("userId", user)
                        .uniqueResult();
                // If the letter isn't already in the database make a new Letter
                if (newLetter == null) {
                     letterMap.put(ch, new Letter(ch, user));
                } else {
                     newLetter.increment();
                     letterMap.put(ch, newLetter);
                }
            } else {
                letterMap.get(ch).increment();
            }
        }

        // Update the letters to the database
        for(Letter letter : letterMap.values()) {
            session.persist(letter);
        }
    }

    /**
     * Increment the number of guesses for the current word and every letter in it for both the
     * current user and the global user.
     * @param word The word to be added/
     */
    public void addWord(String word) {
        lock.lock();
        try {
            Session session = sessionFactory.openSession();
            Transaction transaction = session.beginTransaction();
            try {
                addWord(word, currentUser, session);
                addWord(word, globalUser, session);
                transaction.commit();
            } catch (Exception e) {
                transaction.rollback();
                e.printStackTrace();
            } finally {
                session.close();
            }
        } finally {
            lock.unlock();
        }
    }

    // Get a list of all words guessed by a given user in decreasing order by guessCount
    private List<Word> getWordList(User user, Session session) {
        return session
                .createQuery("FROM Word w WHERE w.user = :userId ORDER BY w.guessCount DESC",
                        Word.class)
                .setParameter("userId", user)
                .list();
    }

    /**
     * Get a list of all words guessed by the current user in decreasing order by guessCount
     * @return
     */
    public List<Word> getWordListLocal() {
        List<Word> wordList;
        lock.lock();
        try (Session session = sessionFactory.openSession()) {
            wordList = getWordList(currentUser, session);
        } finally {
            lock.unlock();
        }
        return wordList;
    }

    /**
     * Get a list of all words guessed by anyone in decreasing order by guessCount
     * @return
     */
    public List<Word> getWordListGlobal() {
        List<Word> wordList;
        lock.lock();
        try (Session session = sessionFactory.openSession()) {
            wordList = getWordList(globalUser, session);
        } finally {
            lock.unlock();
        }
        return wordList;
    }

    // Get a list of all letters guessed by a given user in decreasing order by guessCount
    private List<Letter> getLetterList(User user, Session session) {
        List<Letter> letterList = session
                .createQuery("FROM Letter l WHERE l.user = :userId ORDER BY l.guessCount DESC",
                        Letter.class)
                .setParameter("userId", user)
                .list();

        return letterList;
    }

    /**
     * Get a list of all letters guessed by the current user in decreasing order by guessCount
     * @return
     */
    public List<Letter> getLetterListLocal() {
        List<Letter> letterList;
        lock.lock();
        try (Session session = sessionFactory.openSession()) {
            letterList = getLetterList(currentUser, session);
        } finally {
            lock.unlock();
        }
        return letterList;
    }

    /**
     * Get a list of all letters guessed by anyone in decreasing order by guessCount
     * @return
     */
    public List<Letter> getLetterListGlobal() {
        List<Letter> letterList;
        lock.lock();
        try (Session session = sessionFactory.openSession()) {
            letterList = getLetterList(globalUser, session);
        } finally {
            lock.unlock();
        }
        return letterList;
    }

    /**
     * Add a new database entry for a game by the current user
     * @param guessCount The number of guesses in that game
     */
    public void addGame(int guessCount) {
        lock.lock();
        try {
            Session session = sessionFactory.openSession();
            Transaction transaction = session.beginTransaction();
            try {
                session.persist(new Game(currentUser, guessCount));
                transaction.commit();
            } catch (Exception e) {
                transaction.rollback();
                e.printStackTrace();
            } finally {
                session.close();
            }
        } finally {
            lock.unlock();
        }
    }

    private double averageGuesses(User user, Session session) {
        // Note: this will return null if the current user has not played any games.
        return session
                .createQuery("SELECT AVG(g.guessCount) FROM Game g WHERE g.user = :userId",
                        Double.class)
                .setParameter("userId", user)
                .uniqueResult();
    }

    /**
     * Get the average number of guesses for games by the current user
     * @return
     */
    public double averageGuessesLocal() {
        Double average;
        lock.lock();
        try (Session session = sessionFactory.openSession()) {
            average = session
                    .createQuery("SELECT AVG(g.guessCount) FROM Game g WHERE g.user = :userId",
                            Double.class)
                    .setParameter("userId", currentUser)
                    .uniqueResult();
            if (average == null) {
                average = 0d;
            }
        } finally {
            lock.unlock();
        }
        return average;
    }

    private double averageGuessesAll(Session session) {
        Double avg = session.createQuery("SELECT AVG(g.guessCount) FROM Game g", Double.class)
                .uniqueResult();
        if (avg == null) {
            avg = 0d;
        }
        return avg;
    }

    private long[] guessesList(int maxGuesses, User user, Session session) {
        long[] guessesList = new long[maxGuesses];
        for (int i = 0; i < maxGuesses; ++i) {
            guessesList[i] = session
                    .createQuery(
                            "SELECT COUNT(*) FROM Game g WHERE g.user = :userId AND g.guessCount = :guessCount",
                            Long.class)
                    .setParameter("userId", user)
                    .setParameter("guessCount", i + 1)
                    .uniqueResult();
        }
        return guessesList;
    }

    private long[] guessesListAll(int maxGuesses, Session session) {
        long[] guessesList = new long[maxGuesses];
        for (int i = 0; i < maxGuesses; ++i) {
            guessesList[i] = session
                    .createQuery(
                            "SELECT COUNT(*) FROM Game g WHERE g.guessCount = :guessCount",
                            Long.class)
                    .setParameter("guessCount", i + 1)
                    .uniqueResult();
        }
        return guessesList;
    }

    /**
     * Get a list containing the quantity of each number of guesses by the current user
     * @return
     */
    public long[] guessesListLocal(int maxGuesses) {
        long[] guessesList;
        lock.lock();
        try (Session session = sessionFactory.openSession()) {
            guessesList = guessesList(maxGuesses, currentUser, session);
        } finally {
            lock.unlock();
        }
        return guessesList;
    }

    public StatHolder statsLocal(int maxGuesses) {
        StatHolder stats = new StatHolder();
        lock.lock();
        try (Session session = sessionFactory.openSession()) {
            stats.setAverage(averageGuesses(currentUser, session));
            stats.setLetters(getLetterList(currentUser, session));
            stats.setGuessNums(guessesList(maxGuesses, currentUser, session));
            stats.setWords(getWordList(currentUser, session));
        } finally {
            lock.unlock();
        }
        return stats;
    }

    public StatHolder statsGlobal(int maxGuesses) {
        StatHolder stats = new StatHolder();
        lock.lock();
        try (Session session = sessionFactory.openSession()) {
            stats.setAverage(averageGuessesAll(session));
            stats.setLetters(getLetterList(globalUser, session));
            stats.setGuessNums(guessesListAll(maxGuesses, session));
            stats.setWords(getWordList(globalUser, session));
        } finally {
            lock.unlock();
        }
        return stats;
    }

    public class StatHolder {
        private long[] guessNums;
        private List<Letter> letters;
        private double average;
        private List<Word> words;


        public long[] getGuessNums() {
            return guessNums;
        }

        public void setGuessNums(long[] guessNums) {
            this.guessNums = guessNums;
        }

        public List<Letter> getLetters() {
            return letters;
        }

        public void setLetters(List<Letter> letters) {
            this.letters = letters;
        }

        public double getAverage() {
            return average;
        }

        public void setAverage(double average) {
            this.average = average;
        }

        public List<Word> getWords() {
            return words;
        }

        public void setWords(List<Word> words) {
            this.words = words;
        }
    }
}