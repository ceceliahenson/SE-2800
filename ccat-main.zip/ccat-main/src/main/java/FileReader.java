import javafx.stage.FileChooser;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class FileReader {
    /**
     * Author: Cece
     * imports the wordle file
     */
    protected static void importFiles(ArrayList<String> list){
        Scanner s;
        try {
            s = new Scanner(new File("src/main/resources/wordle-official.txt"));
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        while (s.hasNext()){
            list.add(s.next());
        }
        s.close();
    }

    /**
     * Author: Cece
     * Lets the admin change the vocabulary text file that is being
     * used in the game
     * @param list
     * @throws FileNotFoundException
     */
    protected static void adminImport(ArrayList<String> list) throws FileNotFoundException {
        Scanner s;
        try{
            FileChooser file = new FileChooser();
            File chosenFile = file.showOpenDialog(null);
            s = new Scanner(chosenFile);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        while (s.hasNext()){
            list.add(s.next());
        }
        s.close();
    }
}
