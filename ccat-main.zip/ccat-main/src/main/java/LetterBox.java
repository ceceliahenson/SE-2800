import javafx.animation.*;
import javafx.scene.control.Label;
import javafx.util.Duration;

/**
 * @author Coltrane
 *
 * A box that can contain a single letter as well as information about its guess status. Can be in
 * the state of "non guessed", "correct", "wrong spot" or "incorrect"
 */
public class LetterBox {
    private static final double ANIMATION_SIZE = 0.04;
    private static final int DEFAULT_WIDTH = 63;
    private static final int SMALL_WIDTH = 40;
    private final Label visual;
    private final ScaleTransition scaleAnimation;
    private final TranslateTransition shakeAnimation;


    public LetterBox(Label visual, boolean isSmall) {
        // Set visual
        this.visual = visual;
        int width;
        if (isSmall) {
            this.visual.getStyleClass().add("small-letter");
            width = SMALL_WIDTH;
        } else {
            width = DEFAULT_WIDTH;
        }
        this.visual.getStyleClass().add("letter-box");
        this.visual.setPrefWidth(width);
        // Create scale animation
        scaleAnimation = new ScaleTransition(Duration.millis(100), visual);
        scaleAnimation.setByX(ANIMATION_SIZE);
        scaleAnimation.setByY(ANIMATION_SIZE);
        scaleAnimation.setCycleCount(2);
        scaleAnimation.setAutoReverse(true);
        scaleAnimation.setInterpolator(Interpolator.EASE_BOTH);
        // Create shake animation
        shakeAnimation = new TranslateTransition(Duration.millis(50), visual);
        shakeAnimation.setByX(5);
        shakeAnimation.setCycleCount(6);
        shakeAnimation.setAutoReverse(true);
        shakeAnimation.setInterpolator(Interpolator.EASE_BOTH);
    }

    public LetterBox(Label visual) {
        this(visual, false);
    }

    public void setText(String text) {
        visual.setText(text);
        if (!text.equals("")) {
            scaleAnimation.play();
        }
    }

    public void setStatus(LetterStatus status) {
        scaleAnimation.play();
        visual.getStyleClass().add(status.getStyleClass());
    }

    public void shake() {
        shakeAnimation.play();
    }
}
