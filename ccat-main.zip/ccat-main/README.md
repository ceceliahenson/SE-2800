## Introduction

This is the repository for the course project for SE2800.  The project is developed using the Scrum development process utilizing 3-week sprints.

## Group Members
Trevor Kapugia

Aydin Ruppe

Cecelia Henson

Coltrane Bautch

## Installation Instructions
Java 17, JavaFX 19

## Release Notes

## Known Defects