Features Implemented:
1. As a user, I would like to be able to enter a 5-letter word to be able to tell whether it is a valid word
2. As a user, I would like to see which letters in my word are in the reference word to better tune my guesses
3. As a user, I would like to be able to enter up to 6 guesses to be able to get closer to the right answer
4. As a user, I would like to see a listing of which letters I tried, and which are in the word to be able to better guess
   the words.
5. As a user, I would like to see the number of guesses it has taken me for the current word so I can track my
   progress

Instructions:
Provided by a team member during activity (aka press the green button)

Known Defects: 
- Highlights 2 of the same letters yellow even when there is only one in the word

Support Representative: Cece